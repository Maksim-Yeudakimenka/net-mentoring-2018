import System
import b

a = 4 + b

print(a)